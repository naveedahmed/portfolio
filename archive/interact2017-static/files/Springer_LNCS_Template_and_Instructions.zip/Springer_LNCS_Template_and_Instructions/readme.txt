Folder Contents
------------------

ms_word_template
-
1. Author Instructions - SPLNPROC_Author_Instructions_Feb2015.pdf
2. MS Word Instructions - SPLNPROC_Word_2003_Technical_Instructions_1104.pdf
3. MS Word Template - svlnproc1104.dot

llncs2e_latex_template
-
All the files required for the LaTeX format

------------------

Source
-
https://www.springer.com/computer/lncs?SGWID=0-164-6-793341-0

as on April 26, 2016

------------------


ZIP file created for INTERACT 2017 (www.interact2017.org)
Updated: Dec 17, 2016